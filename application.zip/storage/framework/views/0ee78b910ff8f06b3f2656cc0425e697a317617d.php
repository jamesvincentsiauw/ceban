<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <?php if($message = Session::get('success')): ?>
                    <div class="alert alert-success alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong><?php echo e($message); ?></strong>
                    </div>
                <?php elseif($message = Session::get('alert')): ?>
                    <div class="alert alert-success alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong><?php echo e($message); ?></strong>
                    </div>
                <?php endif; ?>
                <div class="card">
                    <div class="card-header">Data Penjualan</div>

                    <div class="table-responsive">
                        <table class="table"  style="text-align: center">
                            <thead>
                            <tr>
                                <th>#</th>
                                <th>Nomor Penjualan</th>
                                <th>Nama Pelanggan</th>
                                <th>Total Harga</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <?php $i=1 ?>
                            <?php $__currentLoopData = $penjualan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tbody>
                                <tr>
                                    <td><?php echo e($i); ?></td>
                                    <td><?php echo e($item ->nomorPenjualan); ?></td>
                                    <td><?php echo e($item->namaPelanggan); ?></td>
                                    <td><?php echo e($item->grandTotal); ?></td>
                                    <td>
                                        <form method="post" action="/edit/<?php echo e($item->kodeBarang); ?>">
                                            <?php echo csrf_field(); ?>
                                            <input type="submit" style="font-weight: bold;color: cornflowerblue;text-decoration: none;border: none;background-color: transparent;cursor: pointer" value="Edit"/>
                                        </form>
                                        <form method="post" action="/delete/<?php echo e($item->kodeBarang); ?>">
                                            <?php echo csrf_field(); ?>
                                            <input type="submit" style="font-weight: bold;color: red;text-decoration: none;border: none;background-color: transparent;cursor: pointer" value="Delete"/>
                                        </form>
                                    </td>
                                </tr>
                                </tbody>
                                <?php $i++ ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="newItem">
                    <button class="btn btn-success btn-lg" data-toggle="modal" data-target="#newItemForm" style="background-color: lightblue; color: black; font-weight: 500">
                        Tambah Data
                    </button>
                    <a class="btn btn-success btn-lg" href="/home" style="background-color: indianred; color: black; font-weight: 500">
                        Back to Dashboard
                    </a>
                </div>
            </div>
            <div class="modal fade" id="newItemForm" role="dialog">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <!-- Modal Header -->
                        <div class="modal-header">
                            <h4 class="modal-title" id="labelModalKu">Tambah Data Penjualan</h4>
                        </div>
                        <!-- Modal Body -->
                        <div class="modal-body">
                            <p class="statusMsg"></p>
                            <form method="post" action="/addJual">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="nomorPenjualan">Nomor Penjualan</label>
                                    <input type="text" class="form-control" name="nomorPenjualan" placeholder="Nomor Penjualan"/>
                                </div>
                                <div class="form-group">
                                    <label for="namaPelanggan">Nama Pelanggan</label>
                                    <input type="text" class="form-control" name="namaPelanggan" placeholder="Nama Pelanggan"/>
                                </div>
                                <div class="form-group">
                                    <label for="kodeBarang">Kode Barang</label>
                                    <input type="text" class="form-control" name="kodeBarang" placeholder="Kode Barang"/>
                                </div>
                                <div class="form-group">
                                    <label for="qty">Qty</label>
                                    <input type="number" class="form-control" name="qty" placeholder="Qty"/>
                                </div>
                                <div class="form-group">
                                    <label for="hargaSatuan">Harga Satuan</label>
                                    <input type="number" class="form-control" name="hargaSatuan" placeholder="Harga Satuan"/>
                                </div>
                                <div class="form-group">
                                    <label for="hargaTotal">Harga Total</label>
                                    <input type="number" class="form-control" name="hargaTotal" placeholder="Harga Total"/>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                                    <input type="submit" class="btn btn-primary submitBtn" value="Tambah"/>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OTHER\PD Tiga Saudara\application\resources\views/penjualan.blade.php ENDPATH**/ ?>