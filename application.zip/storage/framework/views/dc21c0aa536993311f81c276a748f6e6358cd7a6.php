<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <?php if($message = Session::get('success')): ?>
                    <div class="alert alert-success alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong><?php echo e($message); ?></strong>
                    </div>
                <?php elseif($message = Session::get('alert')): ?>
                    <div class="alert alert-danger alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong><?php echo e($message); ?></strong>
                    </div>
                <?php endif; ?>
                <div class="card">
                    <div class="card-header">Events</div>
                        <div class="table-responsive">
                            <table class="table"  style="text-align: center">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Nama Event</th>
                                        <th>Poster</th>
                                        <th>Kategori</th>
                                        <th>Lokasi</th>
                                        <th>Harga Tiket</th>
                                        <th>Penyelenggara</th>
                                        <th>Tanggal Event</th>
                                        <th>Jumlah Tiket</th>
                                    </tr>
                                </thead>
                                <?php $i=1 ?>
                                <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tbody>
                                    <tr>
                                        <td><?php echo e($i); ?></td>
                                        <td><?php echo e($item->eventName); ?></td>
                                        <td>
                                            <img width="350px" src="<?php echo e(url($item->poster)); ?>">
                                        </td>
                                        <td><?php echo e($item->category); ?></td>
                                        <td><?php echo e($item->location); ?></td>
                                        <td><?php echo e($item->price); ?></td>
                                        <td><?php echo e($item->organizationName); ?></td>
                                        <td><?php echo e($item->eventDate); ?></td>
                                        <td><?php echo e($item->availableMaximumTicket); ?></td>
                                        <td>
                                            <button data-toggle="modal" data-target="#editItemForm" datasrc="<?php echo e($item); ?>" style="font-weight: bold;color: cornflowerblue;text-decoration: none;border: none;background-color: transparent;cursor: pointer">Edit</button>
                                            <a href="/events/buy/<?php echo e($item->eventID); ?>"style="font-weight: bold;color: forestgreen;text-decoration: none;border: none;background-color: transparent;cursor: pointer">Buy Ticket</a>
                                            <form method="post" action="events/delete/<?php echo e($item->eventID); ?>">
                                                <?php echo csrf_field(); ?>
                                                <input type="submit" style="font-weight: bold;color: red;text-decoration: none;border: none;background-color: transparent;cursor: pointer" value="Delete"/>
                                            </form>
                                        </td>
                                    </tr>
                                    </tbody>
                                    <?php $i++ ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="newItem">
                        <button class="btn btn-success btn-lg" data-toggle="modal" data-target="#newItemForm" style="background-color: lightblue; color: black; font-weight: 500">
                            Add new Event
                        </button>
                        <a class="btn btn-success btn-lg" href="/ceban" style="background-color: indianred; color: black; font-weight: 500">
                            Back to Dashboard
                        </a>
                    </div>
                </div>
                <div class="modal fade" id="newItemForm" role="dialog">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <!-- Modal Header -->
                            <div class="modal-header">
                                <h4 class="modal-title" id="labelModalKu">Add new Event</h4>
                            </div>
                            <!-- Modal Body -->
                            <div class="modal-body">
                                <p class="statusMsg"></p>
                                <form method="post" enctype="multipart/form-data" action="/events">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group">
                                        <label for="eventName">Nama Event</label>
                                        <input type="text" class="form-control" name="eventName" placeholder="Nama Event" required/>
                                    </div>
                                    <div class="form-group">
                                        <label for="poster">Poster Event</label>
                                        <input type="file" class="form-control" name="poster" placeholder="Poster Event" accept="image/*" required/>
                                    </div>
                                    <div class="form-group">
                                        <label for="category">Kategori</label>
                                        <select class="custom-select" name="category" required>
                                            <option value="Workshop">Workshop</option>
                                            <option value="Seminar">Seminar</option>
                                            <option value="Concert">Concert</option>
                                            <option value="Other">Other..</option>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="location">Lokasi</label>
                                        <input type="text" class="form-control" name="location" placeholder="Lokasi Event" required/>
                                    </div>
                                    <div class="form-group">
                                        <label for="price">Harga Tiket Masuk</label>
                                        <input type="number" class="form-control" name="price" placeholder="Harga Tiket Masuk" required/>
                                    </div>
                                    <div class="form-group">
                                        <label for="eventDate">Tanggal Pelaksanaan</label>
                                        <input type="date" class="form-control" name="eventDate" placeholder="Tanggal Pelaksanaan" required/>
                                    </div>
                                    <div class="form-group">
                                        <label for="availableMaximumTicket">Jumlah Tiket</label>
                                        <input type="number" class="form-control" name="availableMaximumTicket" placeholder="Jumlah Tiket" required/>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                                        <input type="submit" class="btn btn-primary submitBtn" value="Tambah"/>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="modal fade" id="editItemForm" role="dialog">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <!-- Modal Header -->
                            <div class="modal-header">
                                <h4 class="modal-title" id="labelModalKu">Edit Event Data</h4>
                            </div>
                            <!-- Modal Body -->
                            <div class="modal-body">
                                <p class="statusMsg"></p>
                                <center><a class="alert alert-danger">Maaf, Fitur Ini Belum Tersedia</a></center>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OTHER\application\resources\views/admin/events.blade.php ENDPATH**/ ?>