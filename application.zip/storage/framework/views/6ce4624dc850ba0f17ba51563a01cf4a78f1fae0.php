<?php $__env->startSection('content'); ?>
    <div class="navigation">
        <ul>
            <li>
                Show Registered Users
                <a href="/users"><b>HERE</b></a>
            </li>
            <li>
                Show Registered Owners
                <a href="/owners"><b>HERE</b></a>
            </li>
            <li>
                Show Registered Events
                <a href="/events"><b>HERE</b></a>
            </li>
            <li>
                My Tickets
                <a href="/mytickets"><b>HERE</b></a>
            </li>
        </ul>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OTHER\application\resources\views/admin/index.blade.php ENDPATH**/ ?>