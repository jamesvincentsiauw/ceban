<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <?php if($message = Session::get('success')): ?>
                    <div class="alert alert-success alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong><?php echo e($message); ?></strong>
                    </div>
                <?php elseif($message = Session::get('alert')): ?>
                    <div class="alert alert-danger alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong><?php echo e($message); ?></strong>
                    </div>
                <?php endif; ?>
                <div class="card">
                    <div class="card-header">Owner</div>

                    <div class="table-responsive">
                        <table class="table"  style="text-align: center">
                            <thead>
                            <tr>
                                <th>#</th>
                                <th>Nama Penyelenggara</th>
                                <th>Email</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <?php $i=1 ?>
                            <?php $__currentLoopData = $owners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tbody>
                                <tr>
                                    <td><?php echo e($i); ?></td>
                                    <td><?php echo e($item->organizationName); ?></td>
                                    <td><?php echo e($item->email); ?></td>
                                    <td>
                                        <?php if($item->email == \Illuminate\Support\Facades\Auth::user()->email): ?>
                                        <button data-toggle="modal" data-target="#editItemForm" datasrc="<?php echo e($item); ?>" style="font-weight: bold;color: cornflowerblue;text-decoration: none;border: none;background-color: transparent;cursor: pointer">Edit</button>
                                            <form method="post" action="owners/delete/<?php echo e($item->email); ?>">
                                                <?php echo csrf_field(); ?>
                                                <input type="submit" style="font-weight: bold;color: red;text-decoration: none;border: none;background-color: transparent;cursor: pointer" value="Delete"/>
                                            </form>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                </tbody>
                                <?php $i++ ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="newItem">
                    <button class="btn btn-success btn-lg" data-toggle="modal" data-target="#newItemForm" style="background-color: lightblue; color: black; font-weight: 500">
                        Be an Owner
                    </button>
                    <a class="btn btn-success btn-lg" href="/ceban" style="background-color: indianred; color: black; font-weight: 500">
                        Back to Dashboard
                    </a>
                </div>
            </div>
            <div class="modal fade" id="newItemForm" role="dialog">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <!-- Modal Header -->
                        <div class="modal-header">
                            <h4 class="modal-title" id="labelModalKu">Be an Owner</h4>
                        </div>
                        <!-- Modal Body -->
                        <div class="modal-body">
                            <p class="statusMsg"></p>
                            <form method="post" action="/owners/add">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="nama">Nama Pemilik</label>
                                    <input type="text" class="form-control" name="nama" value="<?php echo e(\Illuminate\Support\Facades\Auth::user()->name); ?>" disabled/>
                                </div>
                                <div class="form-group">
                                    <label for="email">Email</label>
                                    <input type="text" class="form-control" name="email" value="<?php echo e(\Illuminate\Support\Facades\Auth::user()->email); ?>" disabled/>
                                </div>
                                <div class="form-group">
                                    <label for="organizationName">Nama Organisasi</label>
                                    <input type="text" class="form-control" name="organizationName" placeholder="Nama Organisasi" required/>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                                    <input type="submit" class="btn btn-primary submitBtn" value="Tambah"/>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <div class="modal fade" id="editItemForm" role="dialog">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <!-- Modal Header -->
                        <div class="modal-header">
                            <h4 class="modal-title" id="labelModalKu">Edit Event Data</h4>
                        </div>
                        <!-- Modal Body -->
                        <div class="modal-body">
                            <p class="statusMsg"></p>
                            <center><a class="alert alert-danger">Maaf, Fitur Ini Belum Tersedia</a></center>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OTHER\application\resources\views/admin/owners.blade.php ENDPATH**/ ?>